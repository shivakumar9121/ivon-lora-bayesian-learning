# Experiment evidence

The implementation has passed 12 offline correctness checks on a tiny, randomly initialized Qwen model. These checks verify metric arithmetic, frozen base weights, trainable adapters, IVON posterior restoration, gradient accumulation and equivalence of the memory-saving prediction path.

**The real Qwen2.5-0.5B, three-seed experiment has not yet completed.** No calibration improvement is claimed here. The notebook will generate actual results, a comparison table and reliability plots after the GPU runs finish.

The real-model `smoke` profile completed on CPU using Qwen2.5-0.5B, one seed, 16 training examples, two training steps per optimizer and eight test examples. It exercised actual training, posterior sampling and independent metric recomputation. The run trained 540,672 adapter parameters. Its complete evidence is in `results/smoke_validation/`.

**The smoke metrics are pipeline validation only.** Never present them as the main result or evidence of a calibration benefit. Eight test examples and two steps cannot answer the research question. Values quoted from the original paper are kept separately in `docs/PAPER_REFERENCE.md`.

The quick-profile split check also completed: 512 / 128 / 256 selected train / validation / test questions, with no overlapping IDs or duplicate prompts. The fixed IDs and hashes are in `results/quick_split_check.json`.

To verify a measured result archive, extract it into `runs/quick` and run:

```bash
python -m ivon_lora.report runs/quick
```

This recomputes the metrics from individual predictions and rejects incomplete or inconsistent runs.
