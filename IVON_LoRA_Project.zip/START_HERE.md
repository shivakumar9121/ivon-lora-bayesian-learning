# IVON-LoRA project: start here

Prepared for Siddhu, Pathlavath Shiva Kumar and Gugulothu Ganesh.

## Run the main experiment

1. Open the [prepared Colab notebook](https://colab.research.google.com/drive/1xN7pUAkRs3z864_4bfyQeUFzsn6B-Q5X).
2. The notebook has T4 selected. If disconnected, connect again. Run the cell if it is not already waiting for a file.
3. Click **Choose File** in the cell output and select **IVON_LoRA_Project.zip** from this outputs folder. Do not unzip it for this step.
4. Leave the notebook open. It installs the dependencies, checks the GPU, runs 12 correctness checks, runs a smoke experiment, and runs all three seeds for both optimizers.
5. Save the downloaded measured-results ZIP and save the executed notebook using **File → Download → .ipynb**. If Chrome blocks the automatic download, download `ivon_lora_measured_results.zip` from Colab's Files panel.

The run duration has not been measured on this T4. Colab can disconnect; its temporary files disappear if the runtime is deleted. Save the results promptly. Do not interpret a partial run as a three-seed comparison.

An alternative is to upload `ivon-lora-bayesian-learning/notebooks/IVON_LoRA_Reproduction.ipynb` using Colab's **File → Upload notebook**. That notebook contains the source itself and does not require the project ZIP. Follow its cells from top to bottom.

## What is finished

- Training and evaluation code for Qwen2.5-0.5B on ARC-Easy.
- AdamW-LoRA, IVON mean prediction and IVON posterior prediction.
- Three paired seeds, saved per-example predictions, metric recomputation, comparison tables and plotting code.
- Twelve passing local correctness checks.
- A successful real Qwen smoke experiment on CPU, with both optimizers, two steps each and eight test examples.
- Ten-slide PowerPoint, methodology documentation, and a five-minute professor demonstration/viva guide.

## What is still pending

- The main three-seed GPU experiment. No small-model calibration benefit has been established yet.
- Uploading the full project to GitHub. The [private repository](https://github.com/shivakumar9121/ivon-lora-bayesian-learning) currently contains a committed overview only. The full source is in the supplied ZIP.

Browser file upload was blocked by the extension's file-access setting. Enabling **Allow access to file URLs** in Chrome's extension details allows the assistant to try the supported upload flow again. Alternatively, unzip the project and upload its contents through the repository's **Add file → Upload files** page, preserving the folders. The repository is private and cannot be viewed by the professor without access; it can still be demonstrated while signed in to your account.

## Show the professor tomorrow

Open `Professor_Presentation.pptx`, then the executed notebook, then the measured comparison and reliability plot if the main run completes. Use `SHOW_PROFESSOR.md` for the five-minute speaking order and viva answers.

Until the main run completes, say: **“Our implementation and correctness checks are complete. The real-model smoke run succeeded. The three-seed GPU experiment is still pending, so we cannot yet conclude that IVON improved calibration.”**

The paper's Llama-2 figures and the tiny smoke metrics must not be presented as the main Qwen reproduction results.
