# Finished IVON-LoRA project

Team: Siddhu, Pathlavath Shiva Kumar and Gugulothu Ganesh.

**All six main training runs are complete.** The real three-seed results were produced on a Tesla T4 and independently recomputed from saved predictions.

| Method | Accuracy (%) ↑ | ECE (points) ↓ | NLL ↓ |
|---|---:|---:|---:|
| AdamW-LoRA | 73.18 ± 1.76 | 6.89 ± 2.30 | 0.680 ± 0.005 |
| IVON mean | 72.14 ± 0.23 | 6.99 ± 0.29 | 0.680 ± 0.003 |
| IVON, 10 samples | 69.40 ± 1.37 | 17.95 ± 1.49 | 0.884 ± 0.040 |

IVON mean did not reduce average ECE in this experiment. Its small ECE and NLL differences are within the observed seed variation. Ten-sample prediction had higher average ECE than AdamW. This is a small-scale result under fixed hyperparameters, not a general verdict on IVON or a controlled model-size study. Three seeds and 256 test questions do not establish statistical significance.

## Open these for the professor

1. `ivon-lora-bayesian-learning/Professor_Presentation_Results.pptx` — updated presentation with your measured results and training details.
2. [Executed Colab](https://colab.research.google.com/drive/1xN7pUAkRs3z864_4bfyQeUFzsn6B-Q5X) — T4 confirmation, twelve passing tests, all six training logs and final tables.
3. `ivon-lora-bayesian-learning/results/quick/summary/comparison.png` and `training_curves.png` — actual results and recorded losses.
4. `ivon-lora-bayesian-learning/SHOW_PROFESSOR.md` — five-minute speaking order and viva answers.
5. [Private GitHub repository](https://github.com/shivakumar9121/ivon-lora-bayesian-learning) — committed project ZIP and measured results overview. Sign in to demonstrate it.

The initial `IVON_LoRA_Project.zip` is the runnable starting package already committed to GitHub. `IVON_LoRA_Project_Completed.zip` is the updated package containing measured evidence and revised slides. The compact result ZIP omits checkpoint weights; `ivon_lora_measured_results.zip` from Colab contains the trained adapters and IVON posterior state.

Never describe the paper's Llama-2 numbers or the tiny two-step smoke as your main result. The completed experiment changes the model family, data budget and task coverage; call it a small-scale adaptation.
